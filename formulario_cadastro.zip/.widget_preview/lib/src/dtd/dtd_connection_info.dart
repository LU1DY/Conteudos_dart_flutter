// ignore_for_file: implementation_imports

const String kWidgetPreviewDtdUri = 'ws://127.0.0.1:52672/-CNzVRJzy64=';
const String kWidgetPreviewService =
    'widget-preview-ce4533fa-0feb-437f-86d9-c9c5fc959691';
const String kWidgetPreviewScaffoldStream =
    'WidgetPreviewScaffold-ce4533fa-0feb-437f-86d9-c9c5fc959691';
const String kProjectRootPath =
    r'C:\Users\luidy\Documents\piloto\TESTE\tarefa_botoes';
